cordova plugin remove cordova-plugin-zeep
